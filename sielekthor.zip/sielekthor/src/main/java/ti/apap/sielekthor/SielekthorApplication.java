package ti.apap.sielekthor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SielekthorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SielekthorApplication.class, args);
	}

}
