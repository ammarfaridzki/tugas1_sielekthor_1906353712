package ti.apap.sielekthor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SielekthorApplicationTests {

	@Test
	void contextLoads() {
	}

}
